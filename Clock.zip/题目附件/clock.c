#define _GNU_SOURCE
#include <errno.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#define MAX_JOBS 128
#define NAME_LEN 32
#define DATA_LEN 64

#define INPUT_LEN 256
#define DEFAULT_BATCH_SIZE 0x400
#define MAX_DRAFTS 128
#define DRAFT_NAME_LEN 16
#define MAX_BUFFER_SIZE 0x10000

enum {
    JOB_IDLE = 0,
    JOB_RUNNING,
    JOB_CANCELLED,
    JOB_DONE,
};

typedef struct job {
    int id;
    int delay;
    int state;
    int handler_slot;

    char name[NAME_LEN];
    char data[DATA_LEN];

    void (*handler)(struct job *);
    pthread_t tid;
} job_t;

static job_t *g_jobs[MAX_JOBS];

static pthread_mutex_t g_lock = PTHREAD_MUTEX_INITIALIZER;
static int g_next_id = 1;
static unsigned long g_handled_jobs;
static char *g_batch;
static size_t g_batch_size;

typedef struct {
    char *data;
    size_t size;
    char name[DRAFT_NAME_LEN];
} draft_t;

static draft_t g_drafts[MAX_DRAFTS];

static void setup_io(void)
{
    setvbuf(stdin, NULL, _IONBF, 0);
    setvbuf(stdout, NULL, _IONBF, 0);
    setvbuf(stderr, NULL, _IONBF, 0);
}

static ssize_t read_raw(char *buf, size_t cap)
{
    size_t n = 0;

    while (n < cap) {
        char c;
        if (read(STDIN_FILENO, &c, 1) <= 0)
            break;
        if (c == '\n')
            break;
        buf[n++] = c;
    }
    return (ssize_t)n;
}

static void ask_str(const char *prompt, char *dst, size_t cap)
{
    printf("%s", prompt);
    ssize_t n = read_raw(dst, cap - 1);
    if (n <= 0) {
        puts("");
        exit(0);
    }
    dst[n] = '\0';
}

static int ask_int(const char *prompt)
{
    char buf[32];
    ask_str(prompt, buf, sizeof buf);
    return atoi(buf);
}

static int read_exact(void *buf, size_t len)
{
    size_t got = 0;
    while (got < len) {
        ssize_t n = read(STDIN_FILENO, (char *)buf + got, len - got);
        if (n <= 0)
            return -1;
        got += (size_t)n;
    }
    return 0;
}

static int alloc_slot(void)
{
    for (int i = 0; i < MAX_JOBS; i++)
        if (g_jobs[i] == NULL)
            return i;
    return -1;
}

typedef void (*job_handler_fn)(job_t *job);

typedef struct {
    const char *name;
    job_handler_fn fn;
} handler_slot_t;

static void handle_message(job_t *job);
static void handle_echo(job_t *job);
static void handle_counter(job_t *job);
static void handle_audit(job_t *job);

static const handler_slot_t g_handler_slots[] = {
    {"message", handle_message},
    {"echo", handle_echo},
    {"counter", handle_counter},
    {"audit", handle_audit},
};

#define HANDLER_SLOT_COUNT (sizeof(g_handler_slots) / sizeof(g_handler_slots[0]))

static int handler_slot_for_data(const char *data)
{
    if (!data)
        return 0;
    if (strncmp(data, "echo:", 5) == 0)
        return 1;
    if (strncmp(data, "count:", 6) == 0)
        return 2;
    if (strncmp(data, "audit:", 6) == 0)
        return 3;
    return 0;
}

static job_t *job_new(int delay, const char *name, const char *data)
{
    job_t *job = malloc(sizeof(job_t));
    if (!job)
        return NULL;

    memset(job, 0, sizeof(job_t));
    job->id = g_next_id++;
    job->delay = delay;
    job->state = JOB_IDLE;

    if (name)
        strncpy(job->name, name, NAME_LEN - 1);
    if (data)
        strncpy(job->data, data, DATA_LEN - 1);

    job->handler_slot = handler_slot_for_data(job->data);

    return job;
}

static void handle_message(job_t *job)
{
    printf("[message] job #%d (%s): %s\n", job->id, job->name, job->data);
}

static void handle_echo(job_t *job)
{
    const char *text = strncmp(job->data, "echo:", 5) == 0 ? job->data + 5 : job->data;
    printf("[echo] %s\n", text);
}

static void handle_counter(job_t *job)
{
    g_handled_jobs++;
    printf("[counter] job #%d completed; total=%lu\n", job->id, g_handled_jobs);
}

static void handle_audit(job_t *job)
{
    const char *note = strncmp(job->data, "audit:", 6) == 0 ? job->data + 6 : job->data;
    printf("[audit] id=%d name=%s state=%d note=%s\n", job->id, job->name, job->state,
           note);
}

static void handle(job_t *job)
{
    size_t slot = (unsigned)job->handler_slot;
    if (slot >= HANDLER_SLOT_COUNT)
        slot = 0;
    g_handler_slots[slot].fn(job);
}

static const char gift_message[] __attribute__((used)) = "This is a gift for U!";

static void job_retire(job_t *job)
{
    pthread_mutex_lock(&g_lock);
    for (int i = 0; i < MAX_JOBS; i++)
        if (g_jobs[i] == job)
            g_jobs[i] = NULL;
    free(job);
    pthread_mutex_unlock(&g_lock);
}

static void *worker_main(void *arg)
{
    job_t *job = (job_t *)arg;
    int wait = job->delay;

    if (wait > 0)
        sleep((unsigned)wait);

    if (job->state == JOB_CANCELLED) {
        job_retire(job);
        return NULL;
    }

    if (job->handler)
        job->handler(job);

    job->state = JOB_DONE;
    return NULL;
}

static int job_start(job_t *job)
{
    job->handler = handle;
    job->state = JOB_RUNNING;
    return pthread_create(&job->tid, NULL, worker_main, job);
}

static void cmd_create(void)
{
    int slot = alloc_slot();
    if (slot < 0) {
        puts("[-] job table is full");
        return;
    }

    int delay = ask_int("delay (seconds): ");
    if (delay < 0 || delay > 3600) {
        puts("[-] bad delay");
        return;
    }

    char name[NAME_LEN] = {0};
    char data[DATA_LEN] = {0};
    ask_str("name: ", name, sizeof name);
    ask_str("payload: ", data, sizeof data);

    job_t *job = job_new(delay, name, data);
    if (!job) {
        puts("[-] out of memory");
        return;
    }

    g_jobs[slot] = job;
    if (job_start(job) != 0)
        puts("[-] pthread_create failed");

    printf("[+] job #%d created in slot %d (delay=%d)\n", job->id, slot, delay);
}

static void cmd_cancel(void)
{
    int slot = ask_int("slot: ");
    if (slot < 0 || slot >= MAX_JOBS) {
        puts("[-] bad slot");
        return;
    }

    job_t *job = g_jobs[slot];
    if (!job) {
        puts("[-] empty slot");
        return;
    }

    job->state = JOB_CANCELLED;
    printf("[+] job #%d marked cancelled (slot %d)\n", job->id, slot);
}

static void cmd_list(void)
{
    puts(" slot   id  state  delay  fn       handler             job                name / payload");
    puts(" -------------------------------------------------------------------------------------------");

    for (int i = 0; i < MAX_JOBS; i++) {
        job_t *job = g_jobs[i];
        if (!job)
            continue;
        size_t slot = (unsigned)job->handler_slot;
        const char *name = slot < HANDLER_SLOT_COUNT ? g_handler_slots[slot].name : "invalid";
        printf("  %2d   %3d   %4d  %5d  %-8s %p   %p   %s / %s\n", i, job->id, job->state,
               job->delay, name, (void *)job->handler, (void *)job, job->name, job->data);
    }
}

static int batch_workspace_init(size_t size)
{
    g_batch = malloc(size);
    if (!g_batch)
        return -1;
    g_batch_size = size;
    memset(g_batch, 0, g_batch_size);
    return 0;
}

static void cmd_resize_batch(void)
{
    int size = ask_int("new import workspace size: ");
    if (size < INPUT_LEN || size > MAX_BUFFER_SIZE) {
        puts("[-] bad workspace size");
        return;
    }

    if (g_batch)
        free(g_batch);
    g_batch = NULL;
    g_batch_size = 0;

    if (batch_workspace_init((size_t)size) != 0)
        puts("[-] out of memory");
    else
        printf("[+] import workspace resized to %d bytes\n", size);
}

static int draft_slot(void)
{
    for (int i = 0; i < MAX_DRAFTS; i++)
        if (!g_drafts[i].data)
            return i;
    return -1;
}

static void cmd_draft_save(void)
{
    int slot = draft_slot();
    if (slot < 0) {
        puts("[-] draft table is full");
        return;
    }

    int size = ask_int("draft capacity: ");
    if (size <= 0 || size > MAX_BUFFER_SIZE) {
        puts("[-] bad draft capacity");
        return;
    }

    char name[DRAFT_NAME_LEN] = {0};
    ask_str("draft name: ", name, sizeof name);

    char *data = malloc((size_t)size);
    if (!data) {
        puts("[-] out of memory");
        return;
    }
    memset(data, 0, (size_t)size);
    g_drafts[slot].data = data;
    g_drafts[slot].size = (size_t)size;
    strncpy(g_drafts[slot].name, name, DRAFT_NAME_LEN - 1);
    printf("[+] draft #%d saved (%s, %d bytes)\n", slot, g_drafts[slot].name, size);
}

static void cmd_draft_release(void)
{
    int slot = ask_int("draft slot: ");
    if (slot < 0 || slot >= MAX_DRAFTS || !g_drafts[slot].data) {
        puts("[-] empty draft slot");
        return;
    }

    free(g_drafts[slot].data);
    memset(&g_drafts[slot], 0, sizeof g_drafts[slot]);
    puts("[+] draft released");
}

static void cmd_draft_list(void)
{
    puts(" draft   size   name");
    puts(" ----------------------");
    for (int i = 0; i < MAX_DRAFTS; i++)
        if (g_drafts[i].data)
            printf("   %2d   %5zu   %s\n", i, g_drafts[i].size, g_drafts[i].name);
}

static void cmd_buffer_manager(void)
{
    puts(" 1. resize import workspace");
    puts(" 2. save draft buffer");
    puts(" 3. release draft buffer");
    puts(" 4. list draft buffers");

    switch (ask_int("buffer action: ")) {
    case 1:
        cmd_resize_batch();
        break;
    case 2:
        cmd_draft_save();
        break;
    case 3:
        cmd_draft_release();
        break;
    case 4:
        cmd_draft_list();
        break;
    default:
        puts("[-] unknown buffer action");
        break;
    }
}

typedef struct {
    char line[INPUT_LEN];
    char *field;
} import_frame_t;

static void parse_line(import_frame_t *frame)
{
    char *scan = frame->line;
    char *name = strsep(&scan, "@");
    char *delay_s = strsep(&scan, "@");
    char *payload = strsep(&scan, "@");

    if (!name || !*name)
        return;

    if (!payload || payload < frame->line || payload >= frame->line + INPUT_LEN)
        return;

    int delay = delay_s ? atoi(delay_s) : 0;
    if (delay < 0)
        delay = 0;

    int slot = alloc_slot();
    if (slot < 0) {
        puts("[-] import: job table is full");
        return;
    }

    printf("[import] name=%s delay=%s payload=%s\n", name, delay_s ? delay_s : "(null)", payload);

    job_t *job = job_new(delay, name, payload);
    if (!job) {
        puts("[-] import: out of memory");
        return;
    }

    g_jobs[slot] = job;
    if (job_start(job) != 0)
        puts("[-] import: pthread_create failed");
}

static void parse_batch(char *batch, size_t len)
{
    import_frame_t frame;
    memset(&frame, 0, sizeof frame);
    frame.field = batch;

    size_t off = 0;
    while (off < len) {
        size_t start = off;
        while (off < len && batch[off] != '\n')
            off++;
        size_t n = off - start;

        if (n > INPUT_LEN)
            n = INPUT_LEN;

        memset(frame.line, 0, INPUT_LEN);
        memcpy(frame.line, batch + start, n);

        if (off < len && batch[off] == '\n')
            off++;

        parse_line(&frame);
    }

    free(frame.field);
}

static void cmd_import(void)
{
    int total = ask_int("batch size: ");
    if (total <= 0 || total > 0x1000) {
        puts("[-] bad size");
        return;
    }

    if (!g_batch || (size_t)total > g_batch_size) {
        puts("[-] import workspace is too small; resize it first");
        return;
    }

    char *batch = g_batch;
    memset(batch, 0, g_batch_size);
    if (read_exact(batch, (size_t)total) != 0) {
        puts("[-] short read");
        return;
    }

    parse_batch(batch, (size_t)total);
    g_batch = NULL;
    puts("[+] batch imported");
}

static void cleanup_buffers(void)
{
    if (g_batch)
        free(g_batch);
    for (int i = 0; i < MAX_DRAFTS; i++) {
        free(g_drafts[i].data);
        g_drafts[i].data = NULL;
    }
}

static int initialize_service(void)
{
    if (batch_workspace_init(DEFAULT_BATCH_SIZE) != 0) {
        puts("[-] out of memory");
        return -1;
    }
    return 0;
}

static void menu(void)
{
    printf("> ");
}

int main(void)
{
    setup_io();

    if (initialize_service() != 0)
        return 1;

    puts("Clock v0.1 - simple job scheduler");
    puts("");
    puts("================ Clock :: job scheduler ================");
    puts("  1. create job");
    puts("  2. cancel job");
    puts("  3. list   jobs");
    puts("  4. import jobs");
    puts("  5. buffer manager");
    puts("  6. exit");
    puts("========================================================");

    for (;;) {
        menu();
        switch (ask_int("")) {
        case 1:
            cmd_create();
            break;
        case 2:
            cmd_cancel();
            break;
        case 3:
            cmd_list();
            break;
        case 4:
            cmd_import();
            break;
        case 5:
            cmd_buffer_manager();
            break;
        case 6:
            cleanup_buffers();
            puts("bye");
            return 0;
        default:
            puts("[-] unknown command");
            break;
        }
    }
}
