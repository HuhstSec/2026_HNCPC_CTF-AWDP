#!/usr/bin/env bash
set -euo pipefail

PATCHED_BIN_SRC="/input_files/clock_patched"
PATCHED_BIN_TMP="/home/ctf/clock.new"
TARGET_BIN="/home/ctf/clock"

if [ ! -f "$PATCHED_BIN_SRC" ]; then
	echo "patched binary not found: $PATCHED_BIN_SRC"
	exit 1
fi

cp "$PATCHED_BIN_SRC" "$PATCHED_BIN_TMP"
chown root:ctf "$PATCHED_BIN_TMP"
chmod 750 "$PATCHED_BIN_TMP"
mv -f "$PATCHED_BIN_TMP" "$TARGET_BIN"

if ! pgrep -x xinetd >/dev/null 2>&1; then
	/etc/init.d/xinetd start >/dev/null 2>&1 || true
fi

if [ -x "$TARGET_BIN" ] && pgrep -x xinetd >/dev/null 2>&1; then
	echo "patched binary deployed to /home/ctf/clock and xinetd is running"
else
	echo "patch deployed but validation failed"
	exit 1
fi
