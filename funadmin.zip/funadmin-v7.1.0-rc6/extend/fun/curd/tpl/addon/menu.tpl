<?php

return {%menu%};