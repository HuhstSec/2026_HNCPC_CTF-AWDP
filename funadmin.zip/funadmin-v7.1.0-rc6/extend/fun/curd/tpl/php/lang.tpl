<?php

return [
{%langList%}
];
