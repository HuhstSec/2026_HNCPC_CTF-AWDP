package com.cloudvault;

import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

/**
 * CloudVault 文件上传接口。
 *
 * <p>业务逻辑：接收 multipart 表单里的 file 字段，做后缀黑名单检查（“部分文件类型受限”），
 * 然后把文件落到 webapps/ROOT/uploads/ 下，返回访问地址。</p>
 *
 * <p>注意：该类故意保留了赛题中的缺陷（见 {@link #legacyAsciiName(String)}），
 * 仅用于本地复现与教学，不要用于生产。</p>
 */
@WebServlet(name = "uploadServlet", urlPatterns = {"/upload"}, loadOnStartup = 1)
@MultipartConfig(
        fileSizeThreshold = 1024 * 1024,
        maxFileSize = 10L * 1024 * 1024,
        maxRequestSize = 12L * 1024 * 1024)
public class UploadServlet extends HttpServlet {

    private static final long MAX_SIZE = 10L * 1024 * 1024;

    /** 赛题页脚写的“部分文件类型受限”：禁止可执行/脚本类后缀。 */
    private static final Set<String> FORBIDDEN_EXT = new HashSet<>(Arrays.asList(
            "jsp", "jspx", "jspf", "war", "class", "java", "jar", "sh"));

    @Override
    public void init() {
        try {
            Files.createDirectories(uploadDir());
        } catch (IOException ignored) {
            // 目录建不出来时由上传时再报错
        }
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        resp.sendError(HttpServletResponse.SC_METHOD_NOT_ALLOWED);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        // 中文文件名按 UTF-8 解析（题目环境即如此，Wp 里 filename 为 UTF-8 字节）
        req.setCharacterEncoding("UTF-8");
        resp.setContentType("text/html;charset=UTF-8");
        resp.setCharacterEncoding("UTF-8");
        PrintWriter out = resp.getWriter();

        Part part = null;
        try {
            part = req.getPart("file");
        } catch (Exception e) {
            error(out, "请求解析失败");
            return;
        }
        if (part == null || part.getSize() <= 0) {
            error(out, "请选择要上传的文件");
            return;
        }
        if (part.getSize() > MAX_SIZE) {
            error(out, "单个文件最大 10 MB");
            return;
        }

        String submitted = part.getSubmittedFileName();
        String baseName = fileNameOnly(submitted);
        if (baseName.isEmpty()) {
            error(out, "文件名不合法");
            return;
        }

        // ---- 安全检查：按“解析后的字符串”判断后缀 ----
        if (FORBIDDEN_EXT.contains(extensionOf(baseName))) {
            error(out, "该文件类型已被限制");
            return;
        }

        try {
            Path dir = uploadDir();
            Files.createDirectories(dir);

            // ---- 落盘：历史遗留的单字节文件名归一化（赛题缺陷所在） ----
            String storedName = legacyAsciiName(baseName);
            storedName = storedName.replace('\u0000', '_').replace('/', '_').replace('\\', '_');
            if (storedName.isEmpty()) {
                error(out, "文件名不合法");
                return;
            }

            Path target = dir.resolve(storedName).normalize();
            if (!target.startsWith(dir.normalize())) {
                error(out, "文件名不合法");
                return;
            }

            try (InputStream in = part.getInputStream()) {
                Files.copy(in, target, StandardCopyOption.REPLACE_EXISTING);
            }

            String url = req.getContextPath() + "/uploads/" + storedName;
            out.print("<div class=\"result ok\"><div class=\"r-title\">✓ 上传成功</div>"
                    + "文件访问地址：<a href=\"" + escapeHtml(url) + "\" target=\"_blank\">"
                    + escapeHtml(url) + "</a></div>");
        } catch (IllegalStateException e) {
            error(out, "单个文件最大 10 MB");
        } catch (Exception e) {
            error(out, "上传失败，请稍后重试");
        } finally {
            try {
                part.delete();
            } catch (Exception ignored) {
            }
        }
    }

    /**
     * 历史遗留逻辑：早期存储层只支持单字节文件名，为了“兼容旧客户端”，
     * 这里把每个字符截断成低 8 位后落盘。
     *
     * <p>缺陷：后缀检查用的是截断前的 Java 字符串，落盘用的是截断后的字节。
     * 只要文件名里的字符“低 8 位”拼起来是 {@code .jsp}，检查不命中、
     * 落盘却得到一个真正的 .jsp 文件（Ghost Bits 低位碰撞）。</p>
     */
    private static String legacyAsciiName(String name) {
        byte[] raw = new byte[name.length()];
        for (int i = 0; i < name.length(); i++) {
            raw[i] = (byte) name.charAt(i);
        }
        return new String(raw, StandardCharsets.ISO_8859_1);
    }

    private static String fileNameOnly(String submitted) {
        if (submitted == null) {
            return "";
        }
        String name = submitted;
        int slash = Math.max(name.lastIndexOf('/'), name.lastIndexOf('\\'));
        if (slash >= 0) {
            name = name.substring(slash + 1);
        }
        return name.trim();
    }

    private static String extensionOf(String name) {
        int dot = name.lastIndexOf('.');
        if (dot < 0 || dot == name.length() - 1) {
            return "";
        }
        return name.substring(dot + 1).toLowerCase(Locale.ROOT);
    }

    private Path uploadDir() {
        String real = getServletContext().getRealPath("/uploads");
        if (real == null) {
            real = Paths.get(System.getProperty("java.io.tmpdir"), "cloudvault-uploads").toString();
        }
        return Paths.get(real);
    }

    private static void error(PrintWriter out, String message) {
        out.print("<div class=\"result err\"><div class=\"r-title\">✕ 上传失败</div>"
                + escapeHtml(message) + "</div>");
    }

    private static String escapeHtml(String s) {
        return s.replace("&", "&amp;").replace("<", "&lt;")
                .replace(">", "&gt;").replace("\"", "&quot;");
    }
}
