#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
MAYO 公开运算库
"""

import hashlib
import random

GF_POLY = 0b10011


# --------------------------------------------------------------------------
# GF(16) 基础运算
# --------------------------------------------------------------------------

def gf_mul(a, b):
    a &= 0xF
    b &= 0xF
    r = 0
    while b:
        if b & 1:
            r ^= a
        b >>= 1
        a <<= 1
        if a & 0x10:
            a ^= GF_POLY
    return r & 0xF


def gf_inv(a):
    """GF(2^4) 求逆"""
    a &= 0xF
    if a == 0:
        raise ZeroDivisionError("GF(16): 0 没有逆元")
    for b in range(1, 16):
        if gf_mul(a, b) == 1:
            return b
    raise ZeroDivisionError("GF(16): 逆元查找失败")


def gf_div(a, b):
    """GF(2^4) 除法 a/b"""
    return gf_mul(a & 0xF, gf_inv(b))


def gf_pow(a, e):
    """GF(2^4) 幂运算"""
    r = 1
    for _ in range(e):
        r = gf_mul(r, a)
    return r


# --------------------------------------------------------------------------
# 向量 / 矩阵工具 (所有元素均为 GF(16) 中的 0..15)
# --------------------------------------------------------------------------

def xor_all(vals):
    r = 0
    for v in vals:
        r ^= v
    return r


def mat_mul(A, B):
    n, m, p = len(A), len(B), len(B[0])
    return [[xor_all([gf_mul(A[i][k], B[k][j]) for k in range(m)])
             for j in range(p)] for i in range(n)]


def mat_vec(A, v):
    return [xor_all([gf_mul(A[i][j], v[j]) for j in range(len(v))])
            for i in range(len(A))]


def vec_mat(v, A):
    return [xor_all([gf_mul(v[j], A[j][i]) for j in range(len(v))])
            for i in range(len(A[0]))]


def mat_add(A, B):
    return [[A[i][j] ^ B[i][j] for j in range(len(A[0]))] for i in range(len(A))]


def transpose(M):
    return [list(row) for row in zip(*M)]


def mat_inv(M):
    """GF(16) 上的高斯-约当求逆, 奇异时抛 ValueError"""
    n = len(M)
    A = [list(row) + [1 if i == j else 0 for j in range(n)]
         for i, row in enumerate(M)]
    for col in range(n):
        pivot = None
        for r in range(col, n):
            if A[r][col] != 0:
                pivot = r
                break
        if pivot is None:
            raise ValueError("singular")
        A[col], A[pivot] = A[pivot], A[col]
        inv_p = gf_inv(A[col][col])
        A[col] = [gf_mul(x, inv_p) for x in A[col]]
        for r in range(n):
            if r != col and A[r][col] != 0:
                factor = A[r][col]
                A[r] = [x ^ gf_mul(factor, y) for x, y in zip(A[r], A[col])]
    return [row[n:] for row in A]


def random_invertible(n, rng):
    while True:
        M = [[rng.randint(0, 15) for _ in range(n)] for _ in range(n)]
        try:
            mat_inv(M)
            return M
        except ValueError:
            pass


def nullspace(M, num_vars=None):
    """
    求齐次方程组 M x = 0 解空间的一组基 (GF(16) 上的行最简形).

    M 为若干行, num_vars 为未知量个数 (默认取 M 的列数, 可大于列数时自动补零列)。
    返回基向量列表; 无解空间时返回 []。
    """
    rows = [list(r) for r in M] if M else []
    if num_vars is None:
        num_vars = len(rows[0]) if rows else 0
    for r in rows:
        if len(r) < num_vars:
            r.extend([0] * (num_vars - len(r)))

    pivot_cols = []
    row = 0
    for col in range(num_vars):
        piv = None
        for i in range(row, len(rows)):
            if rows[i][col] != 0:
                piv = i
                break
        if piv is None:
            continue
        rows[row], rows[piv] = rows[piv], rows[row]
        inv_p = gf_inv(rows[row][col])
        rows[row] = [gf_mul(x, inv_p) for x in rows[row]]
        for i in range(len(rows)):
            if i != row and rows[i][col] != 0:
                factor = rows[i][col]
                rows[i] = [x ^ gf_mul(factor, y)
                           for x, y in zip(rows[i], rows[row])]
        pivot_cols.append(col)
        row += 1
        if row == len(rows):
            break

    free_cols = [c for c in range(num_vars) if c not in pivot_cols]
    basis = []
    for fc in free_cols:
        x = [0] * num_vars
        x[fc] = 1
        for idx, pc in enumerate(pivot_cols):
            x[pc] = rows[idx][fc]
        basis.append(x)
    return basis


def rank(vectors):
    """向量组的 GF(16) 秩"""
    if not vectors:
        return 0
    m = [list(v) for v in vectors]
    rows, cols = len(m), len(m[0])
    r = 0
    for col in range(cols):
        pivot = None
        for i in range(r, rows):
            if m[i][col] != 0:
                pivot = i
                break
        if pivot is None:
            continue
        m[r], m[pivot] = m[pivot], m[r]
        inv_p = gf_inv(m[r][col])
        for c in range(cols):
            m[r][c] = gf_mul(m[r][c], inv_p)
        for i in range(rows):
            if i != r and m[i][col] != 0:
                factor = m[i][col]
                for c in range(cols):
                    m[i][c] ^= gf_mul(factor, m[r][c])
        r += 1
        if r == rows:
            break
    return r


# --------------------------------------------------------------------------
# 二次型
# --------------------------------------------------------------------------

def quad_eval(A, x):
    """计算 x^T A x (A 无需对称)"""
    n = len(x)
    s = 0
    for i in range(n):
        xi = x[i]
        if xi == 0:
            continue
        row = A[i]
        for j in range(n):
            if x[j]:
                s ^= gf_mul(gf_mul(xi, row[j]), x[j])
    return s


def sym_part(A):
    """取二次型的对称化矩阵 D = A + A^T, 用于极形式 B(x,y)=x^T D y"""
    n = len(A)
    return [[A[i][j] ^ A[j][i] for j in range(n)] for i in range(n)]


def bilinear_eval(D, x, y):
    """极形式 B(x, y) = x^T D y, 满足 Q(x+y) = Q(x)+Q(y)+B(x,y)"""
    n = len(x)
    s = 0
    for i in range(n):
        if x[i] == 0:
            continue
        row = D[i]
        for j in range(n):
            if y[j]:
                s ^= gf_mul(gf_mul(x[i], row[j]), y[j])
    return s


# --------------------------------------------------------------------------
# 线性方程组 (GF(16))
# --------------------------------------------------------------------------

def solve_linear(M, b):
    """解 M x = b。唯一解时返回列表; 无解或解不唯一时返回 None。"""
    m, n = len(M), len(M[0])
    aug = [list(M[i]) + [b[i]] for i in range(m)]
    row = 0
    for col in range(n):
        pivot = None
        for r in range(row, m):
            if aug[r][col] != 0:
                pivot = r
                break
        if pivot is None:
            continue
        aug[row], aug[pivot] = aug[pivot], aug[row]
        inv_p = gf_inv(aug[row][col])
        aug[row] = [gf_mul(x, inv_p) for x in aug[row]]
        for r in range(m):
            if r != row and aug[r][col] != 0:
                factor = aug[r][col]
                aug[r] = [x ^ gf_mul(factor, y) for x, y in zip(aug[r], aug[row])]
        row += 1
        if row == m:
            break
    for r in range(row, m):
        if aug[r][n] != 0:
            return None
    if row < n:
        return None
    return [aug[r][n] for r in range(n)]


# --------------------------------------------------------------------------
# 公开映射 / 哈希
# --------------------------------------------------------------------------

def Q_public(keys_or_public, x):
    """公开二次映射 Q(x), 返回长度 m 的列表"""
    m = keys_or_public['m']
    A_pub = keys_or_public['A_public']
    return [quad_eval(A_pub[i], x) for i in range(m)]


def hash_to_target(msg, salt, m):
    """H(msg || salt) 取前 m 个半字节作为目标向量"""
    h = hashlib.sha256(msg + salt).digest()
    return [h[i] & 0xF for i in range(m)]


# --------------------------------------------------------------------------
# 协议辅助
# --------------------------------------------------------------------------

def format_vector(v):
    return ",".join(str(x) for x in v)


def parse_vector(s):
    return [int(x) for x in s.strip().split(",")]
