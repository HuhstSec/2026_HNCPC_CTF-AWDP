cd ~/projects/flask-login
ls -la
python3 -m venv venv
source venv/bin/activate
pip install flask flask-sqlalchemy
python3 -c "import app; print('ok')"
git init
git add .
git commit -m 'init flask login'
git remote add origin git@github.com:xiaozhang/flask-login.git
git push -u origin main
cd ~/projects/calc
vim calculator.py
python3 calculator.py '1 + 2 * 3'
pytest test_calculator.py
cd ~/projects/utils
cat utils.py
cd ~/projects/docker
docker compose config
docker build -t myapp .
cd ~/projects/fastapi
pip install fastapi uvicorn
python3 -c 'import main'
cd ~/projects/node
npm install
node server.js
export OPENAI_BASE_URL=https://api.openai.com/v1
curl -fsSL https://get.docker.com | sh
sudo apt update && sudo apt upgrade -y
ssh devbox
scp app.py devbox:~/projects/
crontab -e
git log --oneline
git status
cd ~/projects/flask-login
python3 app.py &
curl http://localhost:5000/login
htop
exit
