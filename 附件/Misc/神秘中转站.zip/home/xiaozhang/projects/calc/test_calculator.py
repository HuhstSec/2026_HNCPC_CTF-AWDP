#!/usr/bin/env python3
"""Unit tests for calculator.py."""

import unittest

import calculator


class CalculatorTests(unittest.TestCase):
    def test_add(self):
        self.assertEqual(calculator.calculate(3, "+", 4), 7)
        self.assertEqual(calculator.calculate(-1.5, "+", 2.5), 1.0)

    def test_subtract(self):
        self.assertEqual(calculator.calculate(10, "-", 4), 6)
        self.assertEqual(calculator.calculate(2, "-", 9), -7)

    def test_multiply(self):
        self.assertEqual(calculator.calculate(6, "*", 3), 18)
        self.assertEqual(calculator.calculate(-4, "*", 5), -20)

    def test_divide(self):
        self.assertEqual(calculator.calculate(5, "/", 2), 2.5)
        self.assertEqual(calculator.calculate(9, "/", 3), 3)

    def test_divide_by_zero(self):
        with self.assertRaises(ZeroDivisionError):
            calculator.calculate(1, "/", 0)

    def test_invalid_operator(self):
        with self.assertRaises(ValueError):
            calculator.calculate(1, "%", 2)

    def test_main_ok(self):
        self.assertEqual(calculator.main(["3", "+", "4"]), 0)
        self.assertEqual(calculator.main(["5", "/", "2"]), 0)

    def test_main_errors(self):
        self.assertEqual(calculator.main(["3", "0", "+"]), 1)  # bad numbers
        self.assertEqual(calculator.main(["1", "/", "0"]), 1)  # div by zero
        self.assertEqual(calculator.main(["1", "%", "2"]), 1)  # bad operator

    def test_main_usage(self):
        self.assertEqual(calculator.main([]), 2)
        self.assertEqual(calculator.main(["3", "+"]), 2)


if __name__ == "__main__":
    unittest.main()