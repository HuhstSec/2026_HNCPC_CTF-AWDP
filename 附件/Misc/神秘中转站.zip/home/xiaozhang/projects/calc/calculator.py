#!/usr/bin/env python3
"""A simple command-line calculator supporting addition, subtraction,
multiplication, and division.

Usage:
    python3 calculator.py <a> <op> <b>

Where <op> is one of: + - * /

Examples:
    python3 calculator.py 3 + 4
    python3 calculator.py 10 - 4
    python3 calculator.py 6 '*' 3
    python3 calculator.py 5 / 2
"""

import sys

OPS = {"+", "-", "*", "/"}


def calculate(a, op, b):
    """Apply the arithmetic operation *op* to numbers *a* and *b*.

    Supports '+', '-', '*', '/'. Raises ZeroDivisionError when dividing by
    zero and ValueError for any unsupported operator.
    """
    if op == "+":
        return a + b
    if op == "-":
        return a - b
    if op == "*":
        return a * b
    if op == "/":
        if b == 0:
            raise ZeroDivisionError("division by zero")
        return a / b
    raise ValueError(f"unsupported operator: {op!r}")


def main(argv):
    """Parse command-line arguments and print the result.

    Returns 0 on success, 1 on computation errors, 2 on bad usage.
    """
    args = list(argv)
    if len(args) != 3:
        print(__doc__.strip())
        return 2

    left, op, right = args
    if op not in OPS:
        print(f"Error: unsupported operator: {op!r} (use one of {sorted(OPS)})")
        return 1

    try:
        a = float(left)
        b = float(right)
    except ValueError:
        print(f"Error: expected numbers, got {left!r} and {right!r}")
        return 1

    try:
        result = calculate(a, op, b)
    except ZeroDivisionError as exc:
        print(f"Error: {exc}")
        return 1

    print(f"{a:g} {op} {b:g} = {result:g}")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))