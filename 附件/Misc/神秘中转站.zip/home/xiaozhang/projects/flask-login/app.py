"""A simple Flask user login system backed by SQLite.

Features:
    - Register a new user (username + password)
    - Login / logout with session cookies
    - Passwords stored as salted hashes (werkzeug.security)
"""

import os
import sqlite3

from flask import (
    Flask,
    flash,
    redirect,
    render_template_string,
    request,
    session,
    url_for,
)
from werkzeug.security import check_password_hash, generate_password_hash

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "users.db")

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "dev-secret-key-change-me")

INDEX_TEMPLATE = """
<!doctype html>
<html>
<head><title>Flask Login</title></head>
<body>
  <h1>Flask 用户登录系统</h1>
  {% with messages = get_flashed_messages() %}
    {% if messages %}
      <ul class="flashes">
      {% for message in messages %}
        <li>{{ message }}</li>
      {% endfor %}
      </ul>
    {% endif %}
  {% endwith %}
  {% if 'username' in session %}
    <p>你好，<strong>{{ session['username'] }}</strong>！你已经登录。</p>
    <p><a href="{{ url_for('logout') }}">退出登录</a></p>
  {% else %}
    <p>你还没有登录。</p>
    <p><a href="{{ url_for('login') }}">登录</a> |
       <a href="{{ url_for('register') }}">注册</a></p>
  {% endif %}
</body>
</html>
"""

AUTH_TEMPLATE = """
<!doctype html>
<html>
<head><title>{{ title }}</title></head>
<body>
  <h1>{{ title }}</h1>
  {% with messages = get_flashed_messages() %}
    {% if messages %}
      <ul class="flashes">
      {% for message in messages %}
        <li>{{ message }}</li>
      {% endfor %}
      </ul>
    {% endif %}
  {% endwith %}
  <form method="post">
    <p><label>用户名: <input type="text" name="username" required></label></p>
    <p><label>密码: <input type="password" name="password" required></label></p>
    <p><button type="submit">{{ button }}</button></p>
  </form>
  <p><a href="{{ url_for('index') }}">返回首页</a></p>
</body>
</html>
"""


def get_db():
    """Return a new SQLite connection with row access by column name."""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    """Create the users table if it does not already exist."""
    with get_db() as conn:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT NOT NULL UNIQUE,
                password_hash TEXT NOT NULL,
                created_at TEXT NOT NULL DEFAULT (datetime('now'))
            )
            """
        )


init_db()


@app.route("/")
def index():
    return render_template_string(INDEX_TEMPLATE)


@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        username = (request.form.get("username") or "").strip()
        password = request.form.get("password") or ""

        if not username or not password:
            flash("用户名和密码不能为空。")
        else:
            with get_db() as conn:
                existing = conn.execute(
                    "SELECT id FROM users WHERE username = ?", (username,)
                ).fetchone()
                if existing:
                    flash("该用户名已被注册。")
                else:
                    conn.execute(
                        "INSERT INTO users (username, password_hash) VALUES (?, ?)",
                        (username, generate_password_hash(password)),
                    )
                    flash("注册成功，请登录。")
                    return redirect(url_for("login"))
    return render_template_string(AUTH_TEMPLATE, title="注册", button="注册")


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = (request.form.get("username") or "").strip()
        password = request.form.get("password") or ""

        with get_db() as conn:
            user = conn.execute(
                "SELECT * FROM users WHERE username = ?", (username,)
            ).fetchone()

        if user and check_password_hash(user["password_hash"], password):
            session.clear()
            session["username"] = user["username"]
            session["user_id"] = user["id"]
            flash("登录成功。")
            return redirect(url_for("index"))
        flash("用户名或密码错误。")
    return render_template_string(AUTH_TEMPLATE, title="登录", button="登录")


@app.route("/logout")
def logout():
    session.clear()
    flash("已退出登录。")
    return redirect(url_for("index"))


if __name__ == "__main__":
    app.run(debug=True)
