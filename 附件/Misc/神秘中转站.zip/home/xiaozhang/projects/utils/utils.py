def add(a: int, b: int) -> int:
    return a + b

def split(s: str, sep: str = ",") -> list[str]:
    return s.split(sep)
