# ~/.bash_logout: executed by bash(1) when login shell exits.
if [[ "$(pwd)" == "$HOME" ]]; then
    clear
fi
