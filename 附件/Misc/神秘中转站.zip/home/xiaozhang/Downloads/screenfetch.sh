#!/usr/bin/env bash
echo 'xiaozhang@devbox  Ubuntu 26.04'
